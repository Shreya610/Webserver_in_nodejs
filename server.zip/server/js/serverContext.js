var Session=require('./session.js');
var uniqid=require('uniqid');
var util=require('util');
function serverContext(sessions)
{
var cookies;
var path;
var response;
var map={};
var wildCard={};
var session;
var sessionTimeout;
var contextToIDMap={};
var loopRunner=function(idList)
{
return new Promise(function(resolve,reject){
var keys=Object.keys(cookies);
//console.log(keys);
var count=0;
for(var k=0;k<keys.length;k++) 
{
count++
//console.log(keys[k]+"kkkkk");
if(idList.indexOf(keys[k])>-1) resolve(keys[k]);
if(count==keys.length) resolve(null);
}
});
}
this.setResponse=function(res)
{
return new Promise(function(resolve,reject)
{
response=res;
resolve(true);
});
}
this.setCookies=function(initCookies)
{
return new Promise(function(resolve,reject)
{
cookies=initCookies;
resolve(true);
});
}
this.setPath=function(contextURL)
{
return new Promise(function(resolve,reject)
{
path=contextURL;
resolve(true);
});
}
this.getSession=function(getNew)
{
return new Promise(function(resolve,reject){
if(contextToIDMap.hasOwnProperty(path))
{
var idList=contextToIDMap[path];
var id;
loopRunner(idList).then(function(result){
id=result;
if(id!=null)
{
resolve(sessions[id]);
}
else
{
if(getNew)
{
var newid = uniqid.time();
response.setHeader("Set-Cookie", [newid+"="+newid]);
var s=new Session(Date.now());
sessions[newid]=s;
contextToIDMap[path].push(newid);
resolve(s);
}
else 
{
resolve(null);
}
}
},function(err){
reject(err)
});
}
else
{
var newid=uniqid.time();
contextToIDMap[path]=new Array();
contextToIDMap[path].push(newid);
response.setHeader("Set-Cookie", [newid+"="+newid]);
var s=new Session(Date.now());
sessions[newid]=s;
console.log(newid+"----------"+sessions);
resolve(s);
}
});
}//getSession ends
this.setSessionTimeout=function(timeout)
{
sessionTimeout=timeout;
}
this.getWildCard=function()
{
return wildCard;
}
this.setWildCard=function(initWildCard)
{
wildCard=initWildCard;
}
this.getMap=function()
{
return map;
}
this.setMap=function(initMap)
{
map=initMap;
}
this.destroySession=function()
{
loopRunner(contextToIDMap[path]).then(function(result){
if(result!=null)
{
delete sessions[result];
contextToIDMap[path].splice(contextToIDMap[result].indexOf(key),1);
}
},function(err){
console.log(err);
});
}


this.observeSessionTimeout=function(){
setTimeout(function(){
for(var key in sessions){
var newTime=Date.now();
var oldTime=sessions[key].getCreationTime();
if((newTime-oldTime)>(sessionTimeOut*1000))
{
delete sessions[key];
contextToIDMap[path].splice(contextToIDMap[path].indexOf(key),1);
}
}
this.observeSessionTimeout();
}, 2000);
}
}
module.exports=serverContext;
