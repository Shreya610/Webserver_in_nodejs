var fs=require('fs');
var appsPath="../../apps";
var boolArray=new Array();
var util=require('util');
function PathProcessor()
{
this.populatePath=function(){
return new Promise(function(resolve,reject){
var map={};
var wildCard={};
var dateMap={};
fs.readdir(appsPath,(err,files)=>{
var count=0;
var newCount=0;
files.forEach(file => {
if(fs.lstatSync(appsPath+"/"+file).isDirectory())
{
map[file]={};
wildCard[file]={};
fs.readdir(appsPath+"/"+file+"/APP-INF",(err,f)=>{
f.forEach(s => {
if(s.match("config.json"))
{
boolArray.push(false);
var p=appsPath+"/"+file+"/APP-INF/config.json"
var configJSON=require(p);
map[file]["services"]=configJSON.services;
wildCard[file]["pattern"]=configJSON.pattern;
var stats = fs.statSync(p);
dateMap[file]=new Date(util.inspect(stats.mtime)).getTime();
boolArray[boolArray.findIndex((currentValue) => {return currentValue==false})]=true;
count++;
if(count==files.length)
{
if(boolArray.every((currentValue) => {return currentValue==true;}))
{
resolve([map,dateMap,wildCard]);
}
}
}//if match wala
});//foreach
});//readdir
}//if directory wala
});//foreach
});//readdir
});
};
}
module.exports=PathProcessor;
