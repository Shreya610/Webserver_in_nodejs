function session(time)
{
this.params={};
var creationTime =time;
this.setParameter=function(key,value)
{
this.params[key]=value;
}
this.getParameter=function(key)
{
return this.params[key];
}
this.getCreationTime=function()
{
return creationTime;
}
}
module.exports=session;
