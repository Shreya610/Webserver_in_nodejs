var getCookies= function (request) {
return new Promise(function(resolve,reject){
var list = {},
rc = request.headers.cookie;
rc && rc.split(';').forEach(function( cookie ) {
var parts = cookie.split('=');
list[parts.shift().trim()] = decodeURI(parts.join('='));
});
resolve(list);
});
}
var ServerContext=require('./serverContext.js');
var http = require('http');
var util=require('util');
var url=require('url');
var fs = require('fs');
var p = require("path");
var RequestProcessor=require('./requestProcessor.js');
var init_params=require('../init/server.json')
var PathProcessor=require('./PathProcessor.js');
var Session = require('./session.js');
var RequestHandler=require('./RequestHandler.js');
var requestHandler=new RequestHandler();
var flag = false;
var pathProcessor=new PathProcessor();
var requestProcessor=new RequestProcessor();
var ServerObject = {};
var dateMap={};
var serverContext;
pathProcessor.populatePath().then(function(result){
ServerObject["map"]=result[0];
ServerObject["sessions"]={};
ServerObject["pattern"]=result[2];
serverContext=new ServerContext(ServerObject["sessions"]);
serverContext.setMap(result[0]);
serverContext.setWildCard(result[2]);
dateMap=result[1];
var appsPath='../../apps'
var count=0;
fs.readdir(appsPath,(err,files)=>{

files.forEach(file => {
count++;
if(fs.lstatSync(appsPath+"/"+file).isDirectory())
{
try
{
var init_script=require(appsPath+"/"+file+"/APP-INF/initialise.js")
init_script.init()
} catch(error)
{
console.log('initialise.js not found !')
}
}
if(count==files.length) flag=true;
})
})
},function(err){
console.log(err);
});
http.createServer(function(request,response){
//
requestHandler.setRequest(request);
requestHandler.setResponse(response);
requestHandler.setDevelopmentMode(true);
requestProcessor.setRequestHandler(requestHandler);

//
var urlParts=url.parse(request.url,true);
var path=urlParts.pathname;
getCookies(request).then(function(result){
ServerObject["cookies"]=result;
},function(err){console.log(err);});
if(path=="/")
{
var filename = p.join(process.cwd(), path);
fs.readFile("index.html", function (err, data) {
      response.writeHead(200, {'Content-Type': 'text/html'});
      response.write(data);
      response.end();
   });

}
else if(flag==true)
{
serverContext.setResponse(response).then(function(result){
serverContext.setCookies(ServerObject['cookies']).then(function(result1){
serverContext.setPath(path.split("/")[1]).then(function(result2)
{
requestProcessor.processRequest(request,response,serverContext);
},function(err2){
console.log(err2+"22")
});
},function(err1){
console.log(err1+"1")
});
},function(err){
console.log(err+"0");
});
}
}).listen(init_params.port);


function aaa(){
setTimeout(function(){
for(var key in dateMap) {
var path="../../apps/"+key+"/APP-INF/config.json";   
var sta = fs.statSync(path);
var newTime=new Date(util.inspect(sta.mtime)).getTime();
var oldTime=dateMap[key];
if((newTime-oldTime)>0)
{
var s=fs.readFileSync(path);

ServerObject['map'][key]=JSON.parse(s)["services"];
serverContext.setMap(ServerObject['map']);
requestProcessor.updateMap(ServerObject['map']);
ServerObject['pattern'][key]=JSON.parse(s)["pattern"];
serverContext.setWildCard(ServerObject['pattern']);
requestProcessor.updateWildCard(ServerObject['pattern']);
//console.log(map[key]);
console.log(dateMap);
dateMap[key]=newTime;
console.log(dateMap)
}

}
aaa();
}, 5000);
}
aaa();
