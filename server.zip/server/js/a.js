var http = require('http');
var url=require('url')
var GetDepartments=require('./GetDepartments.js');
var AddDepartment=require('./AddDepartment.js');
var UpdateDepartment=require('./updateDepartment.js');
var DeleteDepartment=require('./deleteDepartment.js');

http.createServer(function(request, response){

 
var urlParts=url.parse(request.url,true);
var path=urlParts.pathname;
var contexturl='/ajax2018';

var qu=urlParts.query;
 

if(path.split(contexturl)[1].startsWith('/getDepartments'))
{
var d=new GetDepartments();

d.doGet(request,response);

}
if(path.split(contexturl)[1].startsWith('/addDepartment'))
{
var d=new AddDepartment();

d.doPost(request,response);

}
if(path.split(contexturl)[1].startsWith('/updateDepartment'))
{
var d=new UpdateDepartment();

d.doPost(request,response);

}
if(path.split(contexturl)[1].startsWith('/deleteDepartment'))
{
var d=new DeleteDepartment();

d.doPost(request,response);

}


}).listen(1729);
a.txt
Displaying a.txt.
