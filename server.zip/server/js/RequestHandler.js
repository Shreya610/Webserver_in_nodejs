var mime = require('mime-types');
var RequestProcessor=require('./requestProcessor.js')
var fs=require('fs')
var appsPath='../../apps'
function RequestHandler()
{
var writeFlag=false;
var forwardFlag=false;
var redirectFlag=false;
var requestDispatcherString="";
var redirectString=""
var request="";
var response="";
var developmentMode=false;
var writeResponseString="";
var contentType='text/html';
//var map={};
this.forwardRequest=function(d)
{
forwardFlag=true;
requestDispatcherString=d;
this.process();
}
this.redirectRequest=function(d)
{
redirectFlag=true;
redirectString=d;
this.process();
}
this.writeResponse=function(d)
{
writeFlag=true;
writeResponseString=d;
this.process();
}
this.setRequest=function(req)
{
request=req;
}
this.setDevelopmentMode=function(d)
{
developmentMode=d;
}
this.setResponse=function(res)
{

response=res;
}
this.setContentType=function(d)
{
contentType=d;
}
this.process=function(){

if(developmentMode==true)
{
if(writeFlag==true&&(redirectFlag=true||forwardFlag==true))
{
//write
response.writeHead(200,{'Content-Type' : contentType});   
console.log(contentType+"Content aa gya");
response.write(writeResponseString);
response.end();

}
else if((writeFlag==false&&redirectFlag==true&&forwardFlag==true)||writeFlag==false&&redirectFlag==true&&forwardFlag==false)
{
//redirect 
response.writeHead(301,{Location:'/'+redirectString});
response.end();
 }
else if(writeFlag==false&&redirectFlag==false&&forwardFlag==true)
{
//forward
if(requestDispatcherString.endsWith(".html"))
{
var stat=fs.statSync(appsPath+"/"+requestDispatcherString);
response.writeHead(200, {
'Content-Type': 'text/html',
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+"/"+requestDispatcherString);
readStream.pipe(response);

}
else if(requestDispatcherString.endsWith(".htm"))
{
var stat=fs.statSync(appsPath+"/"+requestDispatcherString);
response.writeHead(200, {
'Content-Type': 'text/html',
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+"/"+requestDispatcherString);
readStream.pipe(response);

}
else if(requestDispatcherString.endsWith(".jsp"))
{
var stat=fs.statSync(appsPath+"/"+requestDispatcherString);
response.writeHead(200, {
'Content-Type': 'text/html',
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+"/"+requestDispatcherString);
readStream.pipe(response);

}
else
{
var k=require(appsPath+"/"+requestDispatcherString);
var s=new k();
s.process(this,response);

}

}
if(writeFlag==false&&redirectFlag==false&&forwardFlag==flase)
{
response.writeHead(404);
response.write("all is not well");
response.end();

//exception
}
}
if(developmentMode==false)
{
var stat=fs.statSync('./blankpage.html');
response.writeHead(200, {
'Content-Type': 'text/html',
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+"/"+contextURL+"/index.htm");
readStream.pipe(response);
}
}
}
module.exports=RequestHandler;
