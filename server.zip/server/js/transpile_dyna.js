transpile_dyna=function transpile_dyna(filePath,params)
{
try
{
var fs = require('fs');
var readline = require('readline');
var stream = require('stream');

var file_str=fs.readFileSync(filePath).toString();
var writestream = fs.createWriteStream("sample.html");
var pattern=/\{\{(\s*\w+\s*)\}\}/gim;

var myarray = file_str.match(pattern);
var a;
var key;
for(i=0;i<myarray.length;i++)
{
key=myarray[i];
value=params[key.slice(2,key.length-2).trim()];
if(value!=undefined)
{
//console.log(key.slice(2,key.length-2).trim())
a=file_str.replace(key,value);
file_str=a;
}
}
writestream.write(file_str);
} catch(e)
{
console.log(e)
}
}
transpile_dyna("sample.dyna",{"cool":"TM","hot":"SUNNYYYY"})
module.exports.transpile_dyna=transpile_dyna
