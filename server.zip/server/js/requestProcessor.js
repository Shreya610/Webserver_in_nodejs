var url = require('url');
var fs = require('fs');
var mime = require('mime-types');
var form=require('formidable');
var appsPath="../../apps";
function RequestProcessor()
{
var requestHandler=null;


var processService=function(path,request,response,serverContext)
{
var Service=require(path);
var service=new Service();
var dataObject={"query":{},"raw":{},"filePath":{},"serverContext":serverContext};
if(request.method=="GET")
{
dataObject['query']=url.parse(request.url,true).query;
service.process(requestHandler,dataObject);
}
else
{
if(request.headers['content-type'].indexOf('multipart/form-data')>-1)
{
var form = new formidable.IncomingForm();
form.parse(request, function (err, fields, files) {
var oldpath = files.filetoupload.path;
var newpath = appsPath+files.filetoupload.name;
dataObject.filePath=newPath;
fs.rename(oldpath, newpath, function (err) {
if (err) throw err;
service.process(requestHandler,dataObject);
});
});
}//file is uploaded
else
{
request.on('data',function(data){
dataObject['raw']=JSON.parse(data);
service.process(requestHandler,dataObject);
});
}
}//else if post type request
}//processservice khatam

this.setRequestHandler=function(d)
{
requestHandler=d;
}
var map={};
var wildcard={};
this.updateMap=function(updatedMap)
{
map=updatedMap;
}
this.updateWildCard=function(updatedWildCard)
{
wildCard=updatedWildCard;
}
this.processRequest=function(request,response,serverContext){
map=serverContext.getMap();
wildCard=serverContext.getWildCard();
console.log(wildCard);
var urlParts=url.parse(request.url,true);
var path=urlParts.pathname;
var contextURL=path.split('/')[1];
if('/favicon.ico' == request.url)
{
response.writeHead(200, {
'Content-Type': 'image/x-icon'
});
var readStream=fs.createReadStream('../../resources/favicon.ico');
readStream.pipe(response);
}
else if(map.hasOwnProperty(contextURL))
{
if(fs.existsSync(appsPath+path))
{
if(fs.lstatSync(appsPath+path).isDirectory())
{
if(path.split(contextURL)[1].length<=1)
{
if(fs.existsSync(appsPath+"/"+contextURL+"/index.html"))
{
var stat=fs.statSync(appsPath+"/"+contextURL+"/index.html");
response.writeHead(200, {
'Content-Type': 'text/html',
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+"/"+contextURL+"/index.html");
readStream.pipe(response);
}
else if(fs.existsSync(appsPath+"/"+contextURL+"/index.htm"))
{
var stat=fs.statSync(appsPath+"/"+contextURL+"/index.htm");
response.writeHead(200, {
'Content-Type': 'text/html',
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+"/"+contextURL+"/index.htm");
readStream.pipe(response);
}
else
{
response.writeHead(404);
response.write("index.html or index.htm was not found in the site folder: "+contextURL);
response.end();
}
}
else
{
response.writeHead(404);
response.write("cannot serve the directory at path: "+path+", please specify a file or root directory of the app.");
response.end();
}
}//if request ends at app folder name
else
{
var stat=fs.statSync(appsPath+path);
response.writeHead(200, {
'Content-Type': mime.lookup(path.split(".")[1]),
'Content-Length': stat.size
});
var readStream=fs.createReadStream(appsPath+path);
readStream.pipe(response);
}//if a file is to be served
}
else
{
var services=map[contextURL]["services"];
var patterns=wildCard[contextURL]["pattern"];
var serviceName=path.split(contextURL)[1];
if(serviceName.endsWith("/"))  serviceName=serviceName.substring(0,serviceName.length-1);
var p="";
if(services.hasOwnProperty(serviceName))
{
p=appsPath+"/"+contextURL+"/APP-INF/scripts/"+services[serviceName];
processService(p,request,response,serverContext);
}//if service is fine and no error
else
{
var requiredKey=""
if(patterns!=undefined)
{
var max=0;
var count=0;
var keys=Object.keys(patterns);
for(key in patterns)
{
count++;
var x=serviceName+"/";
var y=key.substring(0,key.length-1);
if(x.startsWith(y))
{
if(max<key.length)
{
max=key.length;
requiredKey=key;
console.log("key mili"+requiredKey);
}
}
console.log("count"+count);
console.log("p_length"+patterns.length);

if(count==keys.length)
{
console.log("count    "+count);
if(requiredKey!="")
{
p=appsPath+"/"+contextURL+"/APP-INF/scripts/"+patterns[requiredKey];
console.log("if ke andar"+p);
}

if(p!="") processService(p,request,response,serverContext);
else
{
response.writeHead(404);
response.write("No service at path: "+path+" is available.");
response.end();
}//error no service no pattern
}
}
console.log(p+"for se bahr");
}//patterns is not undefined
}// if not service but pattern
}//if services
}//if contextURL exists
else
{
response.writeHead(404);
response.write("No site with "+contextURL+" name was Found!");
response.end();
}
}//processRequest
}//request processor
module.exports=RequestProcessor;

