var util=require('util');
var mysql=require('mysql');
function addDepartment()
{
this.process=function(requestHandler,dataObject)
{
var connection=mysql.createConnection({
host:'localhost',
user:'root',
password:'patidar',
database:'ajax2018db'
});
connection.connect();
var a={};
console.log("aaaaa");
var name=dataObject.query["name"];
console.log("bbbbb");
var serverContext=dataObject['serverContext'];
console.log("ccccc");
var session;
serverContext.getSession(true).then(function(result){
session=result;
console.log(util.inspect(session))
console.log(session.getParameter('lalala'));
},function(err){
console.log(err);
});
connection.query('select 1 as result from department where name=?',name,function(err1,row,field){
if(!err1)
{
if(row[0]!=undefined)
{
console.log("sasa");
a["success"]=false;
a["error"]="name already exists"
a["response"]={};
//response.writeHead(200, {'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
else
{
connection.query('insert into department(name) values(?)',name,function(err2,result){
if(err2)
{
a["success"]=false;
a["error"]=err2;
a["response"]={};
//response.writeHead(200, {'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
else
{
connection.query('select code from department where name=?',name.toString(),function(err3,row1,field1){
if(err3)
{
a["success"]=false;
a["error"]=err3;
a["response"]={};
//response.writeHead(200, {'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
else
{
b={};
b["code"]=row1[0]["code"];
b["name"]=name.toString();
a["success"]=true;
a["response"]=b;
//response.writeHead(200, {'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
});
}
});
}
}
else
{
a["success"]=false;
a["error"]=err1;
a["response"]={};
//response.writeHead(200, {'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
});
}//end of process function
}//end of class
module.exports=addDepartment;

