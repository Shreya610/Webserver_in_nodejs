var mysql=require('mysql');

function deleteDepartment()
{
this.process=function(response,dataObject)
{
var connection=mysql.createConnection({
host:'localhost',
user:'root',
password:'joshi',
database:'ajax2018db'
});
connection.connect();
var code=dataObject.raw["code"];
var a={};
connection.query('select 1 as result from department where code=?',code,function(err,row,field){
if(!err)
{
if(row[0]==undefined)
{
a["success"]=false;
a["error"]="department does not exists";
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
else
{
connection.query('delete from department where code=?',code,function(err1,result){
if(err1)
{
a["success"]=false;
a["error"]=err1;
a["response"]={};
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
else
{
a["success"]=true;
a["response"]="department deleted";
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
});
}
}
else
{
a["success"]=false;
a["error"]=err;
a["response"]={};
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
});
}
}
module.exports=deleteDepartment;
