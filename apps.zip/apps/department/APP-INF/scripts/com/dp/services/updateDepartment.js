var mysql=require('mysql');
function updateDepartment()
{
this.process=function(response,dataObject)
{
var connection=mysql.createConnection({
host:'localhost',
user:'root',
password:'patidar',
database:'ajax2018db'
});
connection.connect();
var a={};
name=dataObject.raw["name"];
code=dataObject.raw["code"];
connection.query('select 1 as result from department where code=?',[code],function(err1,row,field){
if(!err1)
{
if(row[0]==undefined)
{
a["success"]=false;
a["exception"]="department does not exists"
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
else
{
connection.query('select 1 as result from department where code!=? and name=?',[code,name],function(err,row2,field2){
if(err)
{
a["success"]=false;
a["error"]=err;
a["response"]={};
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
else
{
if(row2[0]==undefined)
{
connection.query('update department set name=? where code=?',[name,code],function(err2,result){
if(err2)
{
a["success"]=false;
a["error"]=err2;
a["response"]={};
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
else
{
b={};
b["code"]=code;
b["name"]=name.toString();
a["success"]=true;
a["response"]=b;
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
});
}
else
{
a["success"]=false;
a["error"]="name already exists";
a["response"]={};
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
}
});
}
}
else
{
a["success"]=false;
a["error"]=err1;
a["response"]={};
response.writeHead(200, {'Content-type':'application/json'});
response.write(JSON.stringify(a));
response.end();
connection.end();
}
});
}//function of process ends
}//class ends
module.exports=updateDepartment;
