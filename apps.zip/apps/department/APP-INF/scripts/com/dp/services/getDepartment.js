var mysql=require('mysql');
function getDepartments()
{
this.process=function(requestHandler,dataObject)
{
var connection=mysql.createConnection({
host:'localhost',
user:'root',
password:'patidar',
database:'ajax2018db'
});
a={};

var serverContext=dataObject["serverContext"];
var session;
serverContext.getSession(true).then(function(result){
session=result;
console.log("session aya@getDep");
session.setParameter("lalala","papapa");
console.log("pareameter set")
},function(err){
console.log(err);
});
connection.query('select * from department',function(err,rows,fields){
if(!err) {
a["success"]=true;
a["response"]=rows;
a["error"]="";
//console.log(a);
//response.writeHead(200, {'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
else
{
a["success"]=false;
a["response"]={};
a["error"]=err;
//response.writeHead(200,{'Content-type':'application/json'});
requestHandler.setContentType('application/json');
requestHandler.writeResponse(JSON.stringify(a));
//response.end();
connection.end();
}
});
};
};
module.exports=getDepartments;

