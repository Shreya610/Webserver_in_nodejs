var init=function init(){
console.log("load on startup");
}
module.exports.init=init;
